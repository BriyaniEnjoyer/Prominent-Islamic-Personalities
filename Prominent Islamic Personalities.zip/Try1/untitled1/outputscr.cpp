#include "outputscr.h"
#include "ui_outputscr.h"
#include <QPixmap>
#include <QFile>
#include <QTextStream>
#include <QTextEdit>
#include <QStringList>
#include <QDesktopServices>
#include <QDebug>
#include <mainwindow.h>

outputscr::outputscr(QWidget *parent)
    : QDialog(parent), ui(new Ui::outputscr)
{
    qDebug() << "outputscr";
    ui->setupUi(this);
    QPixmap bg(":/images/bg.jpg");

    ui->bglabel->setPixmap(bg.scaled(1280, 720, Qt::KeepAspectRatio));

    connectSimilarButtons();

    QString tag;
    QString inputinfo[5];
    QString inputinfofinal[5];

    // Check if created from Scene2 or MainWindow
    Scene2* scene2Parent = qobject_cast<Scene2*>(parentWidget());
    MainWindow* mainWindowParent = qobject_cast<MainWindow*>(parentWidget());

    if (scene2Parent) {
        // Created from Scene2
        tag = scene2Parent->tag;
        for (int i = 0; i < 5; ++i) {
            inputinfo[i] = scene2Parent->inputinfo[i];
        }
    } else if (mainWindowParent) {
        // Created from MainWindow
        tag = mainWindowParent->selectedText;
        ui->similarlabel->deleteLater();
        ui->similarlabel = nullptr;

        for (int i = 0; i < 5; ++i) {
            inputinfo[i] = "";
        }
    }

    ui->Header->append(tag);
    ui->mainimage->setPixmap(QPixmap(":/images/" + tag + ".png"));
    connect(ui->searchButton, &QPushButton::clicked, this, &outputscr::performGoogleSearch);

    QFile file(":/data/" + tag + ".txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qWarning() << "Failed to open the file.";
        // Handle the error, if needed
    }

    int inputhandler = 0;

    for (int i = 0; i < 5; ++i) {
        if (inputinfo[i] == tag)
            inputinfo[i] = "";
    }

    for (int i = 0; i < 5; ++i) {
        if (inputinfo[i].isEmpty()) {
            continue;
        } else {
            inputinfofinal[inputhandler] = inputinfo[i];
            inputhandler += 1;
            qDebug() << inputinfofinal[inputhandler - 1];
        }
    }

    ui->similar1->setText(inputinfofinal[0]);
    ui->similar2->setText(inputinfofinal[1]);
    ui->similar3->setText(inputinfofinal[2]);
    ui->similar4->setText(inputinfofinal[3]);
    ui->similar5->setText(inputinfofinal[4]);
    ui->bglabel->lower();
    if ((scene2Parent)&&(ui->similar1->text().isEmpty())) {
        delete ui->similarlabel;

    }
    QPushButton *buttonsArray[5] = {ui->similar1, ui->similar2, ui->similar3, ui->similar4, ui->similar5};

    for (int i = 0; i < 5; ++i) {
        if (buttonsArray[i]->text().isEmpty()) {
            // Remove the button from its parent
            delete buttonsArray[i];
            buttonsArray[i] = nullptr;  // Set to nullptr to avoid potential issues
        }
    }
    if (buttonsArray[0] && buttonsArray[0]->text().isEmpty()) {
        ui->similarlabel->deleteLater();
        ui->similarlabel = nullptr;
    }

    QTextStream in(&file);
    QString content = in.readAll();
    file.close();

    // Split the content into lines
    QStringList lines = content.split("\n");

    // Set the formatted text with bold headings
    QString formattedText;

    for (const QString &line : lines) {
        if (!line.isEmpty()) {
            QStringList parts = line.split(":");
            if (parts.size() >= 2) {
                // If the line has a colon, make the first part bold (heading)
                formattedText += "<b>" + parts[0].trimmed() + ":</b>" + parts.mid(1).join(":") + "<br>";
            } else {
                // If no colon, treat it as a regular line
                formattedText += line + "<br>";
            }
        }
    }

    // Set the formatted text to the QTextEdit in the UI
    ui->textEdit->setHtml(formattedText);
    ui->textEdit->setReadOnly(true);  // Set it to read-only

    // Add the Back button and connect it to the goBack slot
    connect(ui->backButton, &QPushButton::clicked, this, &outputscr::goBack);
}

void outputscr::connectSimilarButtons()
{
    connect(ui->similar1, &QPushButton::clicked, this, &outputscr::handleSimilarButton);
    connect(ui->similar2, &QPushButton::clicked, this, &outputscr::handleSimilarButton);
    connect(ui->similar3, &QPushButton::clicked, this, &outputscr::handleSimilarButton);
    connect(ui->similar4, &QPushButton::clicked, this, &outputscr::handleSimilarButton);
    connect(ui->similar5, &QPushButton::clicked, this, &outputscr::handleSimilarButton);
}

void outputscr::handleSimilarButton()
{
    QPushButton *clickedButton = qobject_cast<QPushButton*>(sender());
    if (clickedButton) {
        // Get the parent widget
        QWidget *parent = parentWidget();

        // Check if the parent is a Scene2
        Scene2 *scene2Parent = qobject_cast<Scene2*>(parent);

        if (scene2Parent) {
            // Set the parent scene2's public variable "tag" to the text of the clicked button
            scene2Parent->tag = clickedButton->text();

            // Close the current instance of outputscr
            close();

            // Create a new instance of outputscr
            outputscr *newOutputscr = new outputscr(scene2Parent);
            newOutputscr->show();
        }
    }
}

void outputscr::performGoogleSearch()
{
    QString tag;
    // Check if created from Scene2 or MainWindow
    Scene2* scene2Parent = qobject_cast<Scene2*>(parentWidget());
    MainWindow* mainWindowParent = qobject_cast<MainWindow*>(parentWidget());

    if (scene2Parent) {
        // Created from Scene2
        tag = scene2Parent->tag;
    } else if (mainWindowParent) {
        // Created from MainWindow
        tag = mainWindowParent->selectedText;
    }

    // Construct Google search URL with the tag
    QString searchTerm = tag;
    QUrl searchUrl("https://www.google.com/search?q=" + QUrl::toPercentEncoding(searchTerm));

    // Open the Google search URL in the default web browser
    QDesktopServices::openUrl(searchUrl);
}

void outputscr::goBack()
{
    // Hide the current window
    hide();

    // Get the parent widget
    QWidget *parent = parentWidget();

    // Check if the parent is a MainWindow
    MainWindow *mainWindowParent = qobject_cast<MainWindow*>(parent);

    if (mainWindowParent) {
        // Close the current instance of MainWindow
        mainWindowParent->close();

        // Create a new instance of MainWindow
        MainWindow *newMainWindow = new MainWindow();
        newMainWindow->show();
    } else if (parent) {
        // If the parent is not a MainWindow, show it
        parent->show();
    }
}

outputscr::~outputscr()
{
    delete ui;
}
