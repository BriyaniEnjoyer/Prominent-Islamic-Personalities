
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPixmap>
#include <QLineEdit>
#include<QFile>
#include <QTextStream>
#include<QMessageBox>
#include <QDebug>


    MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QPixmap bg(":/images/bg.jpg");

    ui->bglabel->setPixmap(bg.scaled(1280,720,Qt::KeepAspectRatio));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void dataExtractor(QString target,Ui::MainWindow *ui){

    QFile file(":/data/"+target+".txt");

    file.open(QIODevice::OpenModeFlag::ReadOnly);
    QTextStream in(&file);

    // Read the file line by line
    while (!in.atEnd()) {
        QString line = in.readLine();
        ui->SearchBox->addItem(line);

    }

    file.close();

}
QString field;

QString status="";
bool executed=true;


void MainWindow::on_SearchButton_clicked()
{


    selectedText = ui->SearchBox->currentText();

    if(selection==2)
    {

        if(selectedText!=status){

            executed=true;
            ui->SearchBox->clear();
            QString placeholder="Choose "+selectedText;
            ui->SearchBox->addItem(placeholder);

            status=placeholder;




        }
        else{
            executed=false;
            QMessageBox::warning(this, "Invalid Selection", "Please select a valid item before searching.");
            return;

        }
    }

    else
    {
        executed=true;
        ui->SearchBox->clear();
        QString placeholder="Choose "+selectedText;
        ui->SearchBox->addItem(placeholder);
        status=placeholder;
        pageloader=selectedText;

        dataExtractor(selectedText,ui);
    }
    if(executed==true)
    {
        selection+=1;
    }
    if(selection==3)
    {
        hide();


        if((pageloader=="FIELD")||(pageloader=="ERA")){
            scene2=new Scene2(this);
            scene2->show();
        }
        else if(pageloader=="NAME"){



            Outputscr=new outputscr(this);

            Outputscr->show();

        }
    }

    qDebug() << selection;

}
