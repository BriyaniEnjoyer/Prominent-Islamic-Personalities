#ifndef SCENE3_H
#define SCENE3_H

#include <QDialog>

namespace Ui {
class scene3;
}

class scene3 : public QDialog
{
    Q_OBJECT

public:
    explicit scene3(QWidget *parent = nullptr);
    ~scene3();

private:
    Ui::scene3 *ui;
};

#endif // SCENE3_H
