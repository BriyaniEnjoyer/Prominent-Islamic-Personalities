#include "jurisprudence.h"
#include "ui_jurisprudence.h"

jurisprudence::jurisprudence(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::jurisprudence)
{
    ui->setupUi(this);
}

jurisprudence::~jurisprudence()
{
    delete ui;
}
