#include "scene3.h"
#include "ui_scene3.h"
#include <scene2.h>

scene3::scene3(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::scene3)
{
    ui->setupUi(this);
    ui->person_name->append(((Scene2 *) parentWidget())->tag);
}

scene3::~scene3()
{
    delete ui;
}
