
#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include<scene2.h>
#include<outputscr.h>
#include <QMainWindow>

    QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    QString pageloader;
    QString selectedText;
    int selection=1;


private slots:
    void on_pushButton_clicked();

    void on_SearchButton_clicked();

private:
    Ui::MainWindow *ui;
    Scene2 *scene2;
    outputscr *Outputscr;
};
#endif // MAINWINDOW_H
