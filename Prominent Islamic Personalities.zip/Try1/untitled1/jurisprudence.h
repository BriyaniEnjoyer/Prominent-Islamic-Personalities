#ifndef JURISPRUDENCE_H
#define JURISPRUDENCE_H

#include <QDialog>

namespace Ui {
class jurisprudence;
}

class jurisprudence : public QDialog
{
    Q_OBJECT

public:
    explicit jurisprudence(QWidget *parent = nullptr);
    ~jurisprudence();

private:
    Ui::jurisprudence *ui;
};

#endif // JURISPRUDENCE_H
