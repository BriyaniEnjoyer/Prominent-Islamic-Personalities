#include "scene2.h"
#include "ui_scene2.h"
#include<mainwindow.h>
#include<QPixmap>
#include <QDebug>
#include<QFile>



Scene3::Scene2(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Scene2)
{



    QString inputinfo[5];
    int inputmanager=0;
    ui->setupUi(this);
    ui->Header->append(((MainWindow*)parentWidget())->selectedText);
    QString name= ((MainWindow*)parentWidget())->selectedText;
    QString main_name= ((MainWindow*)parentWidget())->pageloader;

    QFile file(":/"+main_name+"/"+name+".txt");


    file.open(QIODevice::OpenModeFlag::ReadOnly);
    QTextStream in(&file);

    // Read the file line by line
    while (!in.atEnd()) {
        QString line = in.readLine();
        inputinfo[inputmanager]=line;
        inputmanager++;
    }
    file.close();
      QPushButton *buttonsArray[5] = {ui->personimage1, ui->personimage2, ui->personimage3, ui->personimage4, ui->personimage5};
    QTextEdit *persontextArray[5] = {ui->persontext1, ui->persontext2, ui->persontext3, ui->persontext4, ui->persontext5};


    ui->persontext1->append(inputinfo[0]);
    ui->personimage1->setStyleSheet("QPushButton { background-image: url(:/images/" + inputinfo[0] + ".png);background-position: right; }");

    ui->persontext2->append(inputinfo[1]);
    ui->personimage2->setStyleSheet("QPushButton { background-image: url(:/images/" + inputinfo[1] + ".png);background-position: right; }");

    ui->persontext3->append(inputinfo[2]);
    ui->personimage3->setStyleSheet("QPushButton { background-image: url(:/images/" + inputinfo[2] + ".png);background-position: right; }");

    ui->persontext4->append(inputinfo[3]);
    ui->personimage4->setStyleSheet("QPushButton { background-image: url(:/images/" + inputinfo[3] + ".png);background-position: right; }");

    ui->persontext5->append(inputinfo[4]);
    ui->personimage5->setStyleSheet("QPushButton { background-image: url(:/images/" + inputinfo[4] + ".png);background-position: right; }");
    ui->bg->lower();
    for(int i=0;i<5;i++){
    buttonsArray[i]->setProperty("tag", persontextArray[i]->toPlainText());
    }
    for(int a=0;a<5;a++){

        if (persontextArray[a]->toPlainText().isEmpty()){

          delete persontextArray[a];
          delete buttonsArray[a];
          }
    }
    connect(ui->personimage1, &QPushButton::clicked, this, &Scene2::handleButtonPress);
    connect(ui->personimage2, &QPushButton::clicked, this, &Scene2::handleButtonPress);
    connect(ui->personimage3, &QPushButton::clicked, this, &Scene2::handleButtonPress);
    connect(ui->personimage4, &QPushButton::clicked, this, &Scene2::handleButtonPress);
    connect(ui->personimage5, &QPushButton::clicked, this, &Scene2::handleButtonPress);



}
void Scene2::handleButtonPress() {
    // Get the sender button
    QPushButton* senderButton = qobject_cast<QPushButton*>(sender());

    // Access the tag property or any other property you need
    tag = senderButton->property("tag").toString();
    hide();





}

Scene2::~Scene2()
{
    delete ui;
}
