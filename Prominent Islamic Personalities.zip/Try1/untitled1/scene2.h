#ifndef SCENE2_H
#define SCENE2_H
#include<outputscr.h>
#include <QMainWindow>


#include <QDialog>
#include<scene3.h>
namespace Ui {
class Scene2;
}

class Scene2 : public QDialog
{
    Q_OBJECT

public:
    explicit Scene2(QWidget *parent = nullptr);
    QString inputinfo[5];

    QString tag;



    ~Scene2();


private slots:
    void goBack();

private:
    Ui::Scene2 *ui;
    outputscr *Outputscr;




    void handleButtonPress();



};

#endif // SCENE2_H
