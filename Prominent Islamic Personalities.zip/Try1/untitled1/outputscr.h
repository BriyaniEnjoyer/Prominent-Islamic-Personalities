
#ifndef OUTPUTSCR_H
#define OUTPUTSCR_H

#include <QDialog>

    namespace Ui {
    class outputscr;
}

class outputscr : public QDialog
{
    Q_OBJECT

public:
    explicit outputscr(QWidget *parent = nullptr);
    ~outputscr();
private slots:
    void goBack();
    void connectSimilarButtons();
    void handleSimilarButton();


private:
    Ui::outputscr *ui;
    void performGoogleSearch();
};

#endif // OUTPUTSCR_H
