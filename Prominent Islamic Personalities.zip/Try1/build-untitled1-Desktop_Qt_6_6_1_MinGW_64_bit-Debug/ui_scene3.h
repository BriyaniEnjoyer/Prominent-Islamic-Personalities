/********************************************************************************
** Form generated from reading UI file 'scene3.ui'
**
** Created by: Qt User Interface Compiler version 6.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SCENE3_H
#define UI_SCENE3_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>

QT_BEGIN_NAMESPACE

class Ui_Scene3
{
public:

    void setupUi(QDialog *Scene3)
    {
        if (Scene3->objectName().isEmpty())
            Scene3->setObjectName("Scene3");
        Scene3->resize(400, 300);

        retranslateUi(Scene3);

        QMetaObject::connectSlotsByName(Scene3);
    } // setupUi

    void retranslateUi(QDialog *Scene3)
    {
        Scene3->setWindowTitle(QCoreApplication::translate("Scene3", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Scene3: public Ui_Scene3 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SCENE3_H
