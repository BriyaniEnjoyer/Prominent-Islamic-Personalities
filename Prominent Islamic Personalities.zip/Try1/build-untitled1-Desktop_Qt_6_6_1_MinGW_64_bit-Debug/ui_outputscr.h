/********************************************************************************
** Form generated from reading UI file 'outputscr.ui'
**
** Created by: Qt User Interface Compiler version 6.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OUTPUTSCR_H
#define UI_OUTPUTSCR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_outputscr
{
public:
    QLabel *mainimage;
    QTextEdit *Header;
    QTextEdit *textEdit;
    QPushButton *searchButton;

    void setupUi(QDialog *outputscr)
    {
        if (outputscr->objectName().isEmpty())
            outputscr->setObjectName("outputscr");
        outputscr->resize(1280, 720);
        QFont font;
        font.setPointSize(12);
        outputscr->setFont(font);
        mainimage = new QLabel(outputscr);
        mainimage->setObjectName("mainimage");
        mainimage->setGeometry(QRect(70, 50, 200, 200));
        Header = new QTextEdit(outputscr);
        Header->setObjectName("Header");
        Header->setGeometry(QRect(70, 260, 191, 51));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        Header->setFont(font1);
        Header->setStyleSheet(QString::fromUtf8("background:\"transparent\";\n"
"border: none;"));
        Header->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        Header->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        Header->setTextInteractionFlags(Qt::NoTextInteraction);
        textEdit = new QTextEdit(outputscr);
        textEdit->setObjectName("textEdit");
        textEdit->setGeometry(QRect(113, 320, 1021, 331));
        textEdit->setStyleSheet(QString::fromUtf8("background:transparent;\n"
"border:20px blue;"));
        searchButton = new QPushButton(outputscr);
        searchButton->setObjectName("searchButton");
        searchButton->setGeometry(QRect(140, 670, 161, 29));

        retranslateUi(outputscr);

        QMetaObject::connectSlotsByName(outputscr);
    } // setupUi

    void retranslateUi(QDialog *outputscr)
    {
        outputscr->setWindowTitle(QCoreApplication::translate("outputscr", "Dialog", nullptr));
        mainimage->setText(QString());
        Header->setHtml(QCoreApplication::translate("outputscr", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:12pt; font-weight:700; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:400;\"><br /></p></body></html>", nullptr));
        searchButton->setText(QCoreApplication::translate("outputscr", "Learn More", nullptr));
    } // retranslateUi

};

namespace Ui {
    class outputscr: public Ui_outputscr {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OUTPUTSCR_H
