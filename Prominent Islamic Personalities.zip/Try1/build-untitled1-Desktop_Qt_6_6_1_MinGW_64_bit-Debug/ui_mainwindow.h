/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *bglabel;
    QComboBox *SearchBox;
    QPushButton *SearchButton;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1280, 720);
        MainWindow->setMinimumSize(QSize(0, 0));
        MainWindow->setMaximumSize(QSize(1280, 720));
        MainWindow->setAutoFillBackground(false);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        bglabel = new QLabel(centralwidget);
        bglabel->setObjectName("bglabel");
        bglabel->setGeometry(QRect(0, 0, 1280, 720));
        bglabel->setMinimumSize(QSize(0, 0));
        bglabel->setMaximumSize(QSize(1280, 720));
        QFont font;
        font.setStyleStrategy(QFont::PreferDefault);
        font.setHintingPreference(QFont::PreferDefaultHinting);
        bglabel->setFont(font);
        SearchBox = new QComboBox(centralwidget);
        SearchBox->addItem(QString());
        SearchBox->addItem(QString());
        SearchBox->addItem(QString());
        SearchBox->setObjectName("SearchBox");
        SearchBox->setGeometry(QRect(500, 300, 201, 51));
        SearchBox->setAutoFillBackground(false);
        SearchBox->setStyleSheet(QString::fromUtf8(""));
        SearchButton = new QPushButton(centralwidget);
        SearchButton->setObjectName("SearchButton");
        SearchButton->setGeometry(QRect(710, 310, 93, 29));
        QFont font1;
        font1.setKerning(true);
        font1.setStyleStrategy(QFont::PreferDefault);
        font1.setHintingPreference(QFont::PreferDefaultHinting);
        SearchButton->setFont(font1);
        SearchButton->setFocusPolicy(Qt::NoFocus);
        SearchButton->setToolTipDuration(-1);
        SearchButton->setStyleSheet(QString::fromUtf8("QPushButton:pressed {\n"
"    background-color:transparent;\n"
"color:brown;\n"
"}\n"
"\n"
""));
        SearchButton->setFlat(true);
        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        bglabel->setText(QString());
        SearchBox->setItemText(0, QCoreApplication::translate("MainWindow", "NAME", nullptr));
        SearchBox->setItemText(1, QCoreApplication::translate("MainWindow", "ERA", nullptr));
        SearchBox->setItemText(2, QCoreApplication::translate("MainWindow", "FIELD", nullptr));

        SearchButton->setText(QCoreApplication::translate("MainWindow", "SEARCH", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
