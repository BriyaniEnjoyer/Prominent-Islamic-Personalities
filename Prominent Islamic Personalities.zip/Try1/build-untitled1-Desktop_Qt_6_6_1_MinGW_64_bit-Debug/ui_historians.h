/********************************************************************************
** Form generated from reading UI file 'historians.ui'
**
** Created by: Qt User Interface Compiler version 6.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HISTORIANS_H
#define UI_HISTORIANS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_Scene2
{
public:
    QTextEdit *Header;

    void setupUi(QDialog *Scene2)
    {
        if (Scene2->objectName().isEmpty())
            Scene2->setObjectName("Scene2");
        Scene2->resize(1280, 720);
        Header = new QTextEdit(Scene2);
        Header->setObjectName("Header");
        Header->setGeometry(QRect(420, 40, 271, 61));
        Header->setReadOnly(true);
        Header->setTextInteractionFlags(Qt::NoTextInteraction);

        retranslateUi(Scene2);

        QMetaObject::connectSlotsByName(Scene2);
    } // setupUi

    void retranslateUi(QDialog *Scene2)
    {
        Scene2->setWindowTitle(QCoreApplication::translate("Scene2", "Dialog", nullptr));
        Header->setHtml(QCoreApplication::translate("Scene2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">HISTORIANS</p></body></html>", nullptr));
        Header->setPlaceholderText(QCoreApplication::translate("Scene2", "HISTORIANS", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Scene2: public Ui_Scene2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HISTORIANS_H
