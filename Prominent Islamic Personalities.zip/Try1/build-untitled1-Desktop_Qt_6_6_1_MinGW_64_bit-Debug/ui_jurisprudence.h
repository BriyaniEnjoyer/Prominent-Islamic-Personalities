/********************************************************************************
** Form generated from reading UI file 'jurisprudence.ui'
**
** Created by: Qt User Interface Compiler version 6.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_JURISPRUDENCE_H
#define UI_JURISPRUDENCE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>

QT_BEGIN_NAMESPACE

class Ui_jurisprudence
{
public:

    void setupUi(QDialog *jurisprudence)
    {
        if (jurisprudence->objectName().isEmpty())
            jurisprudence->setObjectName("jurisprudence");
        jurisprudence->resize(400, 300);

        retranslateUi(jurisprudence);

        QMetaObject::connectSlotsByName(jurisprudence);
    } // setupUi

    void retranslateUi(QDialog *jurisprudence)
    {
        jurisprudence->setWindowTitle(QCoreApplication::translate("jurisprudence", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class jurisprudence: public Ui_jurisprudence {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_JURISPRUDENCE_H
