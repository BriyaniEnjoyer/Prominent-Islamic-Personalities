/********************************************************************************
** Form generated from reading UI file 'scene2.ui'
**
** Created by: Qt User Interface Compiler version 6.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SCENE2_H
#define UI_SCENE2_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Scene2
{
public:
    QTextEdit *Header;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_4;
    QPushButton *personimage2;
    QTextEdit *persontext2;
    QWidget *layoutWidget_2;
    QVBoxLayout *verticalLayout_5;
    QPushButton *personimage3;
    QTextEdit *persontext3;
    QWidget *layoutWidget_3;
    QVBoxLayout *verticalLayout_6;
    QPushButton *personimage4;
    QTextEdit *persontext4;
    QWidget *layoutWidget_4;
    QVBoxLayout *verticalLayout_7;
    QPushButton *personimage5;
    QTextEdit *persontext5;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout;
    QPushButton *personimage1;
    QTextEdit *persontext1;
    QLabel *bg;

    void setupUi(QDialog *Scene2)
    {
        if (Scene2->objectName().isEmpty())
            Scene2->setObjectName("Scene2");
        Scene2->resize(1280, 720);
        QFont font;
        font.setPointSize(12);
        Scene2->setFont(font);
        Header = new QTextEdit(Scene2);
        Header->setObjectName("Header");
        Header->setGeometry(QRect(510, 40, 271, 61));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Sitka Subheading Semibold")});
        font1.setPointSize(24);
        font1.setWeight(QFont::DemiBold);
        font1.setItalic(false);
        Header->setFont(font1);
        Header->setStyleSheet(QString::fromUtf8("background: transparent;\n"
"color: rgb(170, 0, 0);\n"
"\n"
"\n"
"background-color:rgb(218, 208, 199);\n"
"font: 35pt \"Sitka Text\";\n"
"\n"
"\n"
"font: 600 24pt \"Sitka Subheading Semibold\";\n"
"\n"
"\n"
"\n"
"\n"
"border: none;\n"
"\n"
""));
        Header->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        Header->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        Header->setUndoRedoEnabled(false);
        Header->setReadOnly(true);
        Header->setOverwriteMode(false);
        Header->setTextInteractionFlags(Qt::NoTextInteraction);
        layoutWidget = new QWidget(Scene2);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(570, 180, 202, 239));
        verticalLayout_4 = new QVBoxLayout(layoutWidget);
        verticalLayout_4->setObjectName("verticalLayout_4");
        verticalLayout_4->setSizeConstraint(QLayout::SetNoConstraint);
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        personimage2 = new QPushButton(layoutWidget);
        personimage2->setObjectName("personimage2");
        personimage2->setMinimumSize(QSize(0, 200));
        personimage2->setMaximumSize(QSize(200, 16777215));
        personimage2->setFlat(true);

        verticalLayout_4->addWidget(personimage2);

        persontext2 = new QTextEdit(layoutWidget);
        persontext2->setObjectName("persontext2");
        persontext2->setMinimumSize(QSize(200, 0));
        persontext2->setMaximumSize(QSize(200, 30));
        persontext2->setStyleSheet(QString::fromUtf8("background: transparent;\n"
"font: 700 12pt \"Tw Cen MT\";\n"
"font: 700 9pt \"8514oem\";\n"
"background-color: rgb(142, 88, 50);\n"
"color: rgb(218, 208, 199);\n"
"font: 600 12pt \"Sitka Text Semibold\";\n"
"border: none;"));
        persontext2->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        persontext2->setTextInteractionFlags(Qt::NoTextInteraction);

        verticalLayout_4->addWidget(persontext2);

        layoutWidget_2 = new QWidget(Scene2);
        layoutWidget_2->setObjectName("layoutWidget_2");
        layoutWidget_2->setGeometry(QRect(970, 130, 202, 239));
        verticalLayout_5 = new QVBoxLayout(layoutWidget_2);
        verticalLayout_5->setObjectName("verticalLayout_5");
        verticalLayout_5->setSizeConstraint(QLayout::SetNoConstraint);
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        personimage3 = new QPushButton(layoutWidget_2);
        personimage3->setObjectName("personimage3");
        personimage3->setMinimumSize(QSize(0, 200));
        personimage3->setMaximumSize(QSize(200, 16777215));
        personimage3->setFlat(true);

        verticalLayout_5->addWidget(personimage3);

        persontext3 = new QTextEdit(layoutWidget_2);
        persontext3->setObjectName("persontext3");
        persontext3->setMinimumSize(QSize(200, 0));
        persontext3->setMaximumSize(QSize(200, 30));
        persontext3->setStyleSheet(QString::fromUtf8("background: transparent;\n"
"font: 700 12pt \"Tw Cen MT\";\n"
"font: 700 9pt \"8514oem\";\n"
"background-color: rgb(142, 88, 50);\n"
"color: rgb(218, 208, 199);\n"
"font: 600 12pt \"Sitka Text Semibold\";\n"
"border: none;"));
        persontext3->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        persontext3->setTextInteractionFlags(Qt::NoTextInteraction);

        verticalLayout_5->addWidget(persontext3);

        layoutWidget_3 = new QWidget(Scene2);
        layoutWidget_3->setObjectName("layoutWidget_3");
        layoutWidget_3->setGeometry(QRect(290, 440, 202, 239));
        verticalLayout_6 = new QVBoxLayout(layoutWidget_3);
        verticalLayout_6->setObjectName("verticalLayout_6");
        verticalLayout_6->setSizeConstraint(QLayout::SetNoConstraint);
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        personimage4 = new QPushButton(layoutWidget_3);
        personimage4->setObjectName("personimage4");
        personimage4->setMinimumSize(QSize(0, 200));
        personimage4->setMaximumSize(QSize(200, 16777215));
        personimage4->setFlat(true);

        verticalLayout_6->addWidget(personimage4);

        persontext4 = new QTextEdit(layoutWidget_3);
        persontext4->setObjectName("persontext4");
        persontext4->setMinimumSize(QSize(200, 0));
        persontext4->setMaximumSize(QSize(200, 30));
        persontext4->setStyleSheet(QString::fromUtf8("background: transparent;\n"
"font: 700 12pt \"Tw Cen MT\";\n"
"font: 700 9pt \"8514oem\";\n"
"background-color: rgb(142, 88, 50);\n"
"color: rgb(218, 208, 199);\n"
"font: 600 12pt \"Sitka Text Semibold\";\n"
"border: none;"));
        persontext4->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        persontext4->setTextInteractionFlags(Qt::NoTextInteraction);

        verticalLayout_6->addWidget(persontext4);

        layoutWidget_4 = new QWidget(Scene2);
        layoutWidget_4->setObjectName("layoutWidget_4");
        layoutWidget_4->setGeometry(QRect(860, 430, 202, 239));
        verticalLayout_7 = new QVBoxLayout(layoutWidget_4);
        verticalLayout_7->setObjectName("verticalLayout_7");
        verticalLayout_7->setSizeConstraint(QLayout::SetNoConstraint);
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        personimage5 = new QPushButton(layoutWidget_4);
        personimage5->setObjectName("personimage5");
        personimage5->setMinimumSize(QSize(0, 200));
        personimage5->setMaximumSize(QSize(200, 16777215));
        personimage5->setFlat(true);

        verticalLayout_7->addWidget(personimage5);

        persontext5 = new QTextEdit(layoutWidget_4);
        persontext5->setObjectName("persontext5");
        persontext5->setMinimumSize(QSize(200, 0));
        persontext5->setMaximumSize(QSize(200, 30));
        persontext5->setStyleSheet(QString::fromUtf8("background: transparent;\n"
"font: 700 12pt \"Tw Cen MT\";\n"
"font: 700 9pt \"8514oem\";\n"
"background-color: rgb(142, 88, 50);\n"
"color: rgb(218, 208, 199);\n"
"font: 600 12pt \"Sitka Text Semibold\";\n"
"border: none;"));
        persontext5->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        persontext5->setTextInteractionFlags(Qt::NoTextInteraction);

        verticalLayout_7->addWidget(persontext5);

        layoutWidget1 = new QWidget(Scene2);
        layoutWidget1->setObjectName("layoutWidget1");
        layoutWidget1->setGeometry(QRect(140, 120, 202, 249));
        verticalLayout = new QVBoxLayout(layoutWidget1);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setSizeConstraint(QLayout::SetNoConstraint);
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        personimage1 = new QPushButton(layoutWidget1);
        personimage1->setObjectName("personimage1");
        personimage1->setMinimumSize(QSize(0, 200));
        personimage1->setMaximumSize(QSize(200, 16777215));
        personimage1->setStyleSheet(QString::fromUtf8(""));
        personimage1->setFlat(true);

        verticalLayout->addWidget(personimage1);

        persontext1 = new QTextEdit(layoutWidget1);
        persontext1->setObjectName("persontext1");
        persontext1->setMinimumSize(QSize(200, 0));
        persontext1->setMaximumSize(QSize(200, 30));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Sitka Text Semibold")});
        font2.setPointSize(12);
        font2.setWeight(QFont::DemiBold);
        font2.setItalic(false);
        persontext1->setFont(font2);
        persontext1->setStyleSheet(QString::fromUtf8("background: transparent;\n"
"font: 700 12pt \"Tw Cen MT\";\n"
"font: 700 9pt \"8514oem\";\n"
"background-color: rgb(142, 88, 50);\n"
"color: rgb(218, 208, 199);\n"
"font: 600 12pt \"Sitka Text Semibold\";\n"
"border: none;\n"
""));
        persontext1->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        persontext1->setTextInteractionFlags(Qt::NoTextInteraction);

        verticalLayout->addWidget(persontext1);

        bg = new QLabel(Scene2);
        bg->setObjectName("bg");
        bg->setEnabled(true);
        bg->setGeometry(QRect(0, 0, 1280, 720));
        bg->setStyleSheet(QString::fromUtf8("background-image: url(:/images/scene2bg.jpg);\n"
"background-position: center;\n"
"background-repeat: no-repeat;\n"
""));
        bg->setScaledContents(false);
        bg->raise();
        Header->raise();
        layoutWidget1->raise();
        layoutWidget_2->raise();
        layoutWidget_3->raise();
        layoutWidget_4->raise();
        layoutWidget1->raise();

        retranslateUi(Scene2);

        QMetaObject::connectSlotsByName(Scene2);
    } // setupUi

    void retranslateUi(QDialog *Scene2)
    {
        Scene2->setWindowTitle(QCoreApplication::translate("Scene2", "Dialog", nullptr));
        Header->setHtml(QCoreApplication::translate("Scene2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Sitka Subheading Semibold'; font-size:24pt; font-weight:600; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'Segoe UI'; font-size:28pt; font-weight:1000;\"><br /></p></body></html>", nullptr));
        Header->setPlaceholderText(QString());
        personimage2->setText(QString());
        persontext2->setHtml(QCoreApplication::translate("Scene2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Sitka Text Semibold'; font-size:12pt; font-weight:600; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'Segoe UI'; font-size:9pt; font-weight:400;\"><br /></p></body></html>", nullptr));
        personimage3->setText(QString());
        persontext3->setHtml(QCoreApplication::translate("Scene2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Sitka Text Semibold'; font-size:12pt; font-weight:600; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'Segoe UI'; font-size:9pt; font-weight:400;\"><br /></p></body></html>", nullptr));
        personimage4->setText(QString());
        persontext4->setHtml(QCoreApplication::translate("Scene2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Sitka Text Semibold'; font-size:12pt; font-weight:600; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'Segoe UI'; font-size:9pt; font-weight:400;\"><br /></p></body></html>", nullptr));
        personimage5->setText(QString());
        persontext5->setHtml(QCoreApplication::translate("Scene2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Sitka Text Semibold'; font-size:12pt; font-weight:600; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'Segoe UI'; font-size:9pt; font-weight:400;\"><br /></p></body></html>", nullptr));
        personimage1->setText(QString());
        persontext1->setHtml(QCoreApplication::translate("Scene2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Sitka Text Semibold'; font-size:12pt; font-weight:600; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'Segoe UI'; font-size:9pt; font-weight:400;\"><br /></p></body></html>", nullptr));
        bg->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Scene2: public Ui_Scene2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SCENE2_H
