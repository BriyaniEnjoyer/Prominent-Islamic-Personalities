/********************************************************************************
** Form generated from reading UI file 'acene3.ui'
**
** Created by: Qt User Interface Compiler version 6.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACENE3_H
#define UI_ACENE3_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_scene3
{
public:
    QLabel *label;
    QTextEdit *person_name;

    void setupUi(QDialog *scene3)
    {
        if (scene3->objectName().isEmpty())
            scene3->setObjectName("scene3");
        scene3->resize(1280, 720);
        label = new QLabel(scene3);
        label->setObjectName("label");
        label->setGeometry(QRect(90, 120, 200, 200));
        person_name = new QTextEdit(scene3);
        person_name->setObjectName("person_name");
        person_name->setGeometry(QRect(300, 280, 161, 41));
        person_name->setStyleSheet(QString::fromUtf8("background-color: transparent;"));
        person_name->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        person_name->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        person_name->setTextInteractionFlags(Qt::NoTextInteraction);

        retranslateUi(scene3);

        QMetaObject::connectSlotsByName(scene3);
    } // setupUi

    void retranslateUi(QDialog *scene3)
    {
        scene3->setWindowTitle(QCoreApplication::translate("scene3", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("scene3", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class scene3: public Ui_scene3 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACENE3_H
